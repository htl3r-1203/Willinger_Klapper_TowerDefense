// MagicProjectile.java (nutzt jetzt die neuen Getter)
package com.example.willinger_klapper_towerdefense;

import javafx.geometry.Point2D;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

public class MagicProjectile extends Projectile {
    private final double startX, startY, maxRange;

    public MagicProjectile(Point2D start, Point2D aim,
                           double speed, int damage,
                           Color color, double range) {
        super(start, aim, speed, damage, color);
        this.startX   = start.getX();
        this.startY   = start.getY();
        this.maxRange = range;
    }

    public boolean isExpired() {
        double dx = getX() - startX;
        double dy = getY() - startY;
        return Math.hypot(dx, dy) > maxRange;
    }

    @Override
    public void draw(GraphicsContext gc) {
        gc.setStroke(Color.AQUA);
        gc.setLineWidth(3);
        // hier rufen wir jetzt die Getter auf:
        gc.strokeLine(
                getX() - getDx() * 4,
                getY() - getDy() * 4,
                getX(),
                getY()
        );
        gc.setFill(Color.AQUA);
        gc.fillOval(getX() - 4, getY() - 4, 8, 8);
    }
}
